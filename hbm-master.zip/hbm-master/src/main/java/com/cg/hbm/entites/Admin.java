package com.cg.hbm.entites;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class Admin {

	@Id
	@Email(message = "Invalid email format")
	private String admin_email;
	
	@Size(max = 10, message = "{admin_name.invalid}")
	private String admin_name;

	@NotNull(message = "password cannot be null")
	@Size(min = 5, max = 10, message = "{password.invalid}")
	private String password;

	public Admin() {
	}

	public String getAdmin_email() {
		return admin_email;
	}

	public void setAdmin_email(String admin_email) {
		this.admin_email = admin_email;
	}

	public String getAdmin_name() {
		return admin_name;
	}

	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Admin(@Email(message = "Invalid email format") String admin_email, String admin_name,
			@NotNull @Size(min = 5, max = 8, message = "{password.invalid}") String password) {
		super();
		this.admin_email = admin_email;
		this.admin_name = admin_name;
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [admin_email=" + admin_email + ", admin_name=" + admin_name + ", password=" + password + "]";
	}
}
