package com.cg.hbm.service;

import java.util.List;

import com.cg.hbm.dto.TransactionsDTO;
import com.cg.hbm.entites.Transactions;

public interface ITransactionsService {
	public Transactions addTransactions(TransactionsDTO transactionsDTO);

	public Transactions updateTransactions(Transactions transactions);

	public boolean removeTransactions(int trans_id);

	public List<Transactions> showAllTransactions();

	public Transactions showTransactions(int Transactions_id);
}
