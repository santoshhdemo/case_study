package com.cg.hbm.controller;

import java.util.List;

import javax.validation.Valid;

import com.cg.hbm.dto.BookingDTO;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.service.BookingDetailsServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/booking")
public class BookinDetailsController {

	@Autowired
	private BookingDetailsServiceImpl bookingDetailsServiceImpl;

	@PostMapping(value = "/saveBookingDetails", consumes = "application/json")
	public boolean addBookingDetails(@Valid @RequestBody BookingDTO bookingDTO) {

		return bookingDetailsServiceImpl.addBookingDetails(bookingDTO);
	}

	@PostMapping(value = "/updateBookingDetails", consumes = "application/json")
	public boolean updateBookingDetails(@Valid @RequestBody BookingDetails bookingDetails) {

		return bookingDetailsServiceImpl.updateBookingDetails(bookingDetails);
	}

	@DeleteMapping(value = "/removeBookingDetails/{bookingId}")
	public String removeBookingDetails(@PathVariable("bookingId") int bookingId) {

		return bookingDetailsServiceImpl.removeBookingDetails(bookingId);
	}

	@GetMapping(value = "/getAllBookingDetails")
	public List<BookingDetails> showAllBookingDetails() {

		return bookingDetailsServiceImpl.showAllBookingDetails();
	}

	@GetMapping(value = "/getBookingDetails/{bookingId}")
	public BookingDetails showBookingDetails(@PathVariable int bookingId) {

		return bookingDetailsServiceImpl.showBookingDetails(bookingId);
	}
}
