package com.cg.hbm.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.entites.Admin;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;
import com.cg.hbm.service.AdminServicesImpl;
import com.cg.hbm.service.BookingDetailsServiceImpl;
import com.cg.hbm.service.IHotelService;
import com.cg.hbm.service.IRoomDetailsService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminServicesImpl adminServices;

	@Autowired
	private IHotelService hotelservice;

	@Autowired
	private BookingDetailsServiceImpl bookingDetailsServiceImpl;

	@Autowired
	private IRoomDetailsService roomDetailsService;

	@GetMapping(value = "/signin/{admin_email}/{password}")
	public Admin adminSignin(@PathVariable String admin_email, @PathVariable String password) {
		return adminServices.signIn(admin_email, password);
	}

	@PostMapping(value = "/saveAdmin", consumes = "application/json")
	public Admin saveAdmin(@Valid @RequestBody Admin admin) {

		return adminServices.saveAdmin(admin);
	}

	@PutMapping("/updateAdminDetails")
	public Admin updateAdmin(@Valid @RequestBody Admin admin) {

		return adminServices.updateAdmin(admin);
	}

	@DeleteMapping("/deleteAdmin/{admin_id}")
	public Admin deleteAdmin(@PathVariable String admin_email) {

		return adminServices.deleteAdmin(admin_email);
	}

	@GetMapping("/showAllAdmin")
	public List<Admin> showAllAdmin() {

		return adminServices.showAllAdmin();
	}

	@GetMapping("/showAllHotels")
	public List<Hotel> showAllHotels() {

		return hotelservice.showAllHotels();
	}

	@GetMapping(value = "/getAllBookingDetails")
	public List<BookingDetails> showAllBookingDetails() {

		return bookingDetailsServiceImpl.showAllBookingDetails();
	}

	@GetMapping("/showAllRoomDetails")
	public List<RoomDetails> showAllRoomDetails() {
		return roomDetailsService.showAllRoomDetails();
	}
}
