package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.User;
import com.cg.hbm.exceptions.InvalidNameAndPasswordException;
import com.cg.hbm.exceptions.UserAlreadyExistException;
import com.cg.hbm.exceptions.UserNotFoundException;
import com.cg.hbm.repository.IUserRepository;

@Service("userService")
public class UserService implements IUserService {

	@Autowired
	private IUserRepository userDao;

	@Override
	public User addUser(User user) {
		Optional<User> result = userDao.findById(user.getEmail());
		if (result.isPresent()) {
			throw new UserAlreadyExistException("User already exist with this email Id");
		} else {
			return userDao.save(user);
		}
	}

	@Override
	public User updateUser(User user) {
		Optional<User> opt = userDao.findById(user.getEmail());
		if (opt.isPresent())
			userDao.save(user);
		else
			throw new UserNotFoundException("User does not exist");
		return user;
	}

	@Override
	public User removeUser(String user_email) {
		User user = userDao.findById(user_email)
				.orElseThrow(() -> new UserNotFoundException("No user exist with that id"));
		userDao.delete(user);
		return user;
	}

	@Override
	public List<User> showAllUsers() {
		return userDao.findAll();
	}

	@Override
	public User showUser(String user_email) {
		User user1 = userDao.findById(user_email).orElseThrow(() -> new UserNotFoundException("User not found"));
		return user1;
	}

	@Override
	public User userSignIn(String user_email, String password) {
		User resultUser = userDao.findById(user_email).orElseThrow(() -> new UserNotFoundException("User not found"));

		if (resultUser.getPassword().equals(password)) {
			return resultUser;
		} else {
			throw new InvalidNameAndPasswordException("Invalid User Id or Password");
		}
	}

	@Override
	public double showUserBalance(String user_email) {
		// TODO Auto-generated method stub
		User user1 = userDao.findById(user_email).orElseThrow(() -> new UserNotFoundException("User not found"));
		return user1.getWallet();
	}
	
	
	@Override
	public boolean addUserBalance(String user_email, double amount) {
		// TODO Auto-generated method stub
		User user1 = userDao.findById(user_email).orElseThrow(() -> new UserNotFoundException("User not found"));
		user1.setWallet(user1.getWallet() + amount);
		userDao.save(user1);
		return true;
	}

	@Override
	public List<BookingDetails> showBookingsByEmail(String user_email) {
		// TODO Auto-generated method stub
		return userDao.showBookingsByEmail(user_email);
	}
	

}
