package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.entites.Admin;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;
import com.cg.hbm.exceptions.AdminNotFoundException;
import com.cg.hbm.exceptions.InvalidNameAndPasswordException;
import com.cg.hbm.exceptions.UserAlreadyExistException;
import com.cg.hbm.repository.IAdminRepository;
import com.cg.hbm.repository.IBookingDetailsRepository;
import com.cg.hbm.repository.IHotelRepository;
import com.cg.hbm.repository.IRoomDetailsRepository;

@Service("adminService")
@Transactional
public class AdminServicesImpl implements IAdminService {

	@Autowired
	private IAdminRepository adminRepo;

	@Autowired
	private IBookingDetailsRepository bookingdetailsRepo;

	@Autowired
	private IHotelRepository hotelRepo;

	@Autowired
	private IRoomDetailsRepository roomDetailsRepo;

	@Override
	public Admin signIn(String admin_email, String password) {

		Optional<Admin> result = adminRepo.findById(admin_email);
		Admin resultAdmin = result.get();

		if (resultAdmin.getPassword().equals(password)) {
			return resultAdmin;
		} else {
			throw new InvalidNameAndPasswordException("Invalid User Id or Password");
		}
	}

	@Override
	public Admin signOut(Admin admin) {
		return null;
	}

	@Override
	public Admin saveAdmin(Admin admin) {

		Optional<Admin> result = adminRepo.findById(admin.getAdmin_email());
		if (result.isPresent()) {
			throw new UserAlreadyExistException("Admin already exist with this email id");
		} else {
			return adminRepo.save(admin);
		}
	}

	@Override
	public Admin updateAdmin(Admin admin) {

		Optional<Admin> result = adminRepo.findById(admin.getAdmin_email());

		if (result.isPresent()) {
			adminRepo.save(admin);
		} else {
			throw new AdminNotFoundException("No Admin available to update with given Admin Id");
		}

		return admin;
	}

	@Override
	public Admin deleteAdmin(String admin_email) {

		Optional<Admin> result = adminRepo.findById(admin_email);

		if (result.isPresent())
			adminRepo.delete(result.get());
		else
			throw new AdminNotFoundException("No Admin availabe with given Admin Id");

		return result.get();
	}

	@Override
	public List<Admin> showAllAdmin() {

		return adminRepo.findAll();
	}

	@Override
	public List<Hotel> showAllHotels() {
		return hotelRepo.findAll();
	}

	@Override
	public List<BookingDetails> showAllBookingDetails() {
		return bookingdetailsRepo.findAll();
	}

	@Override
	public List<RoomDetails> showAllRoomDetails() {
		return roomDetailsRepo.findAll();
	}

}
