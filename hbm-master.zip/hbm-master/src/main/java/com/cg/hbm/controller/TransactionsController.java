package com.cg.hbm.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.dto.TransactionsDTO;
import com.cg.hbm.entites.Transactions;
import com.cg.hbm.service.ITransactionsService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/Transactions")
public class TransactionsController {

	@Autowired
	private ITransactionsService transactionsService;

	@PostMapping(value = "/saveTransactions", consumes = "application/json")
	public Transactions addTransactions(@Valid @RequestBody TransactionsDTO transactionsDTO) {

		return transactionsService.addTransactions(transactionsDTO);
	}

	@PutMapping("/updateTransactions")
	public Transactions updateTransactions(@Valid @RequestBody Transactions transactions) {
		return transactionsService.updateTransactions(transactions);
	}

	@DeleteMapping("/removeTransactions/{trans_id}")
	public boolean removeTransactions(@PathVariable int trans_id) {
		return transactionsService.removeTransactions(trans_id);
	}

	@GetMapping("/showAllTransactions")
	public List<Transactions> showAllTransactions() {
		return transactionsService.showAllTransactions();
	}

	@GetMapping("/showTransactionsByID/{trans_id}")
	public String showTransactions(@PathVariable int trans_id) {
		return transactionsService.showTransactions(trans_id).toString();
	}
}
