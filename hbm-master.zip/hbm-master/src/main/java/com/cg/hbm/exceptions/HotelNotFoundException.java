package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class HotelNotFoundException extends RuntimeException {

	public HotelNotFoundException() {
	}

	public HotelNotFoundException(String msg) {
		super(msg);
	}
}
