package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class BookingDetailsNotFoundException extends RuntimeException {

	public BookingDetailsNotFoundException() {
	}

	public BookingDetailsNotFoundException(String message) {
		super(message);
	}

}
