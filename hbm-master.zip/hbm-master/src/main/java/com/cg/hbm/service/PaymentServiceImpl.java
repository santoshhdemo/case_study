package com.cg.hbm.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.dto.PaymentsDTO;
import com.cg.hbm.entites.Payments;
import com.cg.hbm.repository.IPaymentRepository;

@Service("paymentService")
@Transactional
public class PaymentServiceImpl implements IPaymentService {

	@Autowired
	private IPaymentRepository paymentRepository;

	@Override
	public Payments addPayment(PaymentsDTO paymentDTO) {
		Payments payment = new Payments();
		payment.setMode(paymentDTO.getMode());

		return paymentRepository.save(payment);
	}

	@Override
	public List<Payments> showAllPayments() {
		return paymentRepository.findAll();
	}
}
