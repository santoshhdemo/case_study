package com.cg.hbm.exceptionHandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.cg.hbm.exceptions.AdminNotFoundException;

@ControllerAdvice
public class AdminServiceExceptionHandler {

	@ExceptionHandler(AdminNotFoundException.class)
	public ResponseEntity<MyErrorDetails> handleAdminNotFoundException(AdminNotFoundException ie, WebRequest req) {

		MyErrorDetails err = new MyErrorDetails(LocalDateTime.now(), ie.getMessage(), req.getDescription(false));
		return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);

	}
}
