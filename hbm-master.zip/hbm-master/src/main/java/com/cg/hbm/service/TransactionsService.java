package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.dto.TransactionsDTO;
import com.cg.hbm.entites.Payments;
import com.cg.hbm.entites.Transactions;
import com.cg.hbm.exceptions.PaymentsNotFoundException;
import com.cg.hbm.exceptions.TransactionsNotFoundException;
import com.cg.hbm.repository.IPaymentRepository;
import com.cg.hbm.repository.ITransactionsRepository;
import com.cg.hbm.repository.IUserRepository;

@Service("transactionsService")
@Transactional
public class TransactionsService implements ITransactionsService {

	@Autowired
	ITransactionsRepository Transactionsdao;

	@Autowired
	IPaymentRepository paymentReop;
	
	@Autowired
	IUserRepository userRepo;

	@Override
	public Transactions addTransactions(TransactionsDTO transactionsDTO) {
		Payments payment = paymentReop.findById(transactionsDTO.getPayment_id())
				.orElseThrow(() -> new PaymentsNotFoundException("Payment does not exist"));
		
		Transactions transactions = new Transactions();
		transactions.setDate_of_transaction(transactionsDTO.getDate_of_transaction());
		transactions.setAmount(transactionsDTO.getAmount());
		transactions.setPayment_id(transactionsDTO.getPayment_id());
		transactions.setPayments(payment);
		return Transactionsdao.save(transactions);
	}

	@Override
	public Transactions updateTransactions(Transactions transactions) {
		Optional<Transactions> opt = Transactionsdao.findById(transactions.getTransactions_id());

		if (opt.isPresent())
			Transactionsdao.save(transactions);
		else
			throw new TransactionsNotFoundException("Transactions Does not exist");

		return transactions;
	}

	@Override
	public boolean removeTransactions(int trans_id) {
		Optional<Transactions> opt = Transactionsdao.findById(trans_id);

		if (opt.isPresent())
			Transactionsdao.delete(opt.get());
		else
			throw new TransactionsNotFoundException("Transactions Does not exist");

		return true;
	}

	@Override
	public List<Transactions> showAllTransactions() {
		return Transactionsdao.findAll();
	}

	@Override
	public Transactions showTransactions(int Transactions_id) {
		return Transactionsdao.getById(Transactions_id);
	}

}