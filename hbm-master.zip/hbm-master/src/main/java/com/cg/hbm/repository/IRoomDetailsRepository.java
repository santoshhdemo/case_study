package com.cg.hbm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.hbm.entites.RoomDetails;

public interface IRoomDetailsRepository extends JpaRepository<RoomDetails, Integer> {

	@Query(value = "SELECT rd FROM RoomDetails rd WHERE rd.hotel_id =?1 AND rd.room_type = ?2")
	List<RoomDetails> showRoomDetailsByIdType(int hotel_id, String type);
	
	@Query(value = "SELECT distinct rd FROM RoomDetails rd WHERE rd.hotel_id =?1")
	List<RoomDetails> showRoomTypeByHotelId(int hotel_id);
	
	@Query(value = "SELECT rd FROM RoomDetails rd WHERE rd.hotel_id =?1")
	List<RoomDetails> showRoomDetailsByHotelId(int hotel_id);
}
