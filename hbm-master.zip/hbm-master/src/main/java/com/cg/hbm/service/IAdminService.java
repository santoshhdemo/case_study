package com.cg.hbm.service;

import java.util.List;

import com.cg.hbm.entites.Admin;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;

public interface IAdminService {
	public Admin signIn(String admin_email, String password);

	public Admin signOut(Admin admin);

	public Admin saveAdmin(Admin admin);

	public Admin updateAdmin(Admin admin);

	public Admin deleteAdmin(String admin_email);

	public List<Admin> showAllAdmin();

	public List<Hotel> showAllHotels();

	public List<BookingDetails> showAllBookingDetails();

	public List<RoomDetails> showAllRoomDetails();

}
