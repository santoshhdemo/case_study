package com.cg.hbm.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class TransactionsDTO {
	@NotNull(message = "payment_id cannot be null")
	private int payment_id;
	
	@NotNull(message = "date_of_transaction cannot be null")
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate date_of_transaction;   
	
	private double amount;
	
	public TransactionsDTO() {
		super();
	}
	
	public int getPayment_id() {
		return payment_id;
	}
	
	public void setPayment_id(int payment_id) {
		this.payment_id = payment_id;
	}
	
	public LocalDate getDate_of_transaction() {
		return date_of_transaction;
	}
	
	public void setDate_of_transaction(LocalDate date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}
	
	public double getAmount() {
		return amount;
	}
	
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public TransactionsDTO(int payment_id, LocalDate date_of_transaction, double amount) {
		super();
		this.payment_id = payment_id;
		this.date_of_transaction = date_of_transaction;
		this.amount = amount;
	}
}
