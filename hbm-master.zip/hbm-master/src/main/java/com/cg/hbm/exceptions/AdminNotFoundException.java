package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class AdminNotFoundException extends RuntimeException {

	public AdminNotFoundException() {
	}

	public AdminNotFoundException(String message) {
		super(message);
	}

}
