package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class PaymentsNotFoundException extends RuntimeException {

	public PaymentsNotFoundException() {
	}

	public PaymentsNotFoundException(String message) {
		super(message);
	}
}