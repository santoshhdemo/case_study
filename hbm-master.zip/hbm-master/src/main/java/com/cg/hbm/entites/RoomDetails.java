package com.cg.hbm.entites;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

@Entity
public class RoomDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int room_id;
	
	@NotNull(message = "hotel_id cannot be null")
	private int hotel_id;
	
	private String room_no;

	@NotNull(message = "room_type cannot be null")
	private String room_type;
	
	@NotNull
	private int capacity = 2;
	
	@NotNull
	private String room_desc;
	
	private double rate_per_day;
	
	@NotNull(message = "isAvailable cannot be null")
	private boolean isAvailable;

	@ManyToOne()
	@JoinColumn(name = "h_id")
	private Hotel hotel;

	public RoomDetails() {
	}

	public RoomDetails(int room_id, int hotel_id, String room_no, String room_type, double rate_per_day,
			boolean isAvailable, Hotel hotel, int capacity, String room_desc) {
		super();
		this.room_id = room_id;
		this.hotel_id = hotel_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.rate_per_day = rate_per_day;
		this.isAvailable = isAvailable;
		this.capacity = capacity;
		this.room_desc = room_desc;
		this.hotel = hotel;
	}

	public int getRoom_id() {
		return room_id;
	}

	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}

	public int getHotel_id() {
		return hotel_id;
	}

	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}

	public String getRoom_no() {
		return room_no;
	}

	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}

	public String getRoom_type() {
		return room_type;
	}

	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}

	public double getRate_per_day() {
		return rate_per_day;
	}

	public void setRate_per_day(double rate_per_day) {
		this.rate_per_day = rate_per_day;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getRoom_desc() {
		return room_desc;
	}

	public void setRoom_desc(String room_desc) {
		this.room_desc = room_desc;
	}

	@Override
	public String toString() {
		return "RoomDetails [room_id=" + room_id + ", hotel_id=" + hotel_id + ", room_no=" + room_no + ", room_type="
				+ room_type + ", capacity=" + capacity + ", room_desc=" + room_desc + ", rate_per_day=" + rate_per_day
				+ ", isAvailable=" + isAvailable + ", hotel=" + hotel + "]";
	}

	

}
