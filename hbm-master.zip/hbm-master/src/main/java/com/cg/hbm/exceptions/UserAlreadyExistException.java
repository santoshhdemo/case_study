package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class UserAlreadyExistException extends RuntimeException {

	public UserAlreadyExistException() {
	}

	public UserAlreadyExistException(String e) {
		super(e);
	}
}
