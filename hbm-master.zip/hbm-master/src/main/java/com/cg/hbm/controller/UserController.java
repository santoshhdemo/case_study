package com.cg.hbm.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.User;
import com.cg.hbm.service.IUserService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private IUserService userService;

	@PostMapping(value = "/addUser", consumes = "application/json")
	public User addUser(@Valid @RequestBody User user) {
		return userService.addUser(user);
	}

	@PutMapping("/updateUserDetails")
	public User updateUser(@Valid @RequestBody User user) {
		return userService.updateUser(user);
	}

	@DeleteMapping("/deleteUser/{user_email}")
	public User removeuser(@PathVariable String user_email) {
		return userService.removeUser(user_email);
	}

	@GetMapping("/showAllDetails")
	public List<User> showAllUsers() {
		return userService.showAllUsers();
	}

	@GetMapping("/showUser/{user_email}")
	public User showUser(@PathVariable String user_email) {
		return userService.showUser(user_email);
	}

	@GetMapping(value = "/signin/{user_email}/{password}")
	public User userSignin(@PathVariable String user_email, @PathVariable String password) {
		return userService.userSignIn(user_email, password);
	}
	
	@GetMapping("/showUserBalance/{user_email}")
	public double showUserBalance(@PathVariable String user_email) {
		return userService.showUserBalance(user_email);
	}
	
	
	@GetMapping("/addUserBalance/{user_email}/{amount}")
	public boolean addUserBalance(@PathVariable String user_email, @PathVariable double amount) {
		return userService.addUserBalance(user_email, amount);
	}
	
	@GetMapping("/showBookingsByEmail/{user_email}")
	public List<BookingDetails> showBookingsByEmail(@PathVariable String user_email) {
		return userService.showBookingsByEmail(user_email);
	}
}
