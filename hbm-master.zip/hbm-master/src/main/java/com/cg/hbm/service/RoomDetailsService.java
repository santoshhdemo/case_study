package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;
import com.cg.hbm.exceptions.HotelNotFoundException;
import com.cg.hbm.exceptions.RoomDetailsNotFoundException;
import com.cg.hbm.repository.IHotelRepository;
import com.cg.hbm.repository.IRoomDetailsRepository;

@Service("roomDetailsService")
@Transactional
public class RoomDetailsService implements IRoomDetailsService {

	@Autowired
	private IRoomDetailsRepository roomdetailsrepo;

	@Autowired
	private IHotelRepository hotelRepo;

	@Override
	public boolean addRoomDetails(RoomDetails roomDetails) {

		Hotel hotel = hotelRepo.findById(roomDetails.getHotel_id())
				.orElseThrow(() -> new HotelNotFoundException("Hotel not found"));

		hotel.setAvailable_rooms(hotel.getAvailable_rooms() + 1);

		hotelRepo.save(hotel);

		roomDetails.setHotel(hotel);

		roomdetailsrepo.save(roomDetails);
		
		return true;
	}

	@Override
	public RoomDetails updateRoomDetails(RoomDetails roomDetails) {

		Optional<RoomDetails> opt = roomdetailsrepo.findById(roomDetails.getRoom_id());

		if (opt.isPresent()) {
			Hotel prevHotel = hotelRepo.findById(opt.get().getHotel_id())
					.orElseThrow(() -> new HotelNotFoundException("Hotel not found"));
			
			prevHotel.setAvailable_rooms(prevHotel.getAvailable_rooms() - 1);
			
			hotelRepo.save(prevHotel);
			
			Hotel hotel = hotelRepo.findById(roomDetails.getHotel_id())
					.orElseThrow(() -> new HotelNotFoundException("Hotel not found"));

			hotel.setAvailable_rooms(hotel.getAvailable_rooms() + 1);

			hotelRepo.save(hotel);

			roomDetails.setHotel(hotel);
			
			roomdetailsrepo.save(roomDetails);
		}
		else
			throw new RoomDetailsNotFoundException("Room Details Does not exist");

		return roomDetails;
	}

	@Override
	public boolean removeRoomDetails(int room_id) {
		Optional<RoomDetails> opt = roomdetailsrepo.findById(room_id);

		if (opt.isPresent())
			roomdetailsrepo.delete(opt.get());
		else
			throw new RoomDetailsNotFoundException("Room Details Does not exist");

		return true;
	}

	@Override
	public List<RoomDetails> showAllRoomDetails() {
		return roomdetailsrepo.findAll();
	}

	@Override
	public RoomDetails showRoomDetails(int roomDetails_id) {
		RoomDetails room = roomdetailsrepo.findById(roomDetails_id)
				.orElseThrow(() -> new RoomDetailsNotFoundException());

		return room;
	}

	@Override
	public List<RoomDetails> showRoomDetailsByIdType(int hotel_id, String type) {
		return roomdetailsrepo.showRoomDetailsByIdType(hotel_id, type);
	}

	@Override
	public List<RoomDetails> showRoomDetailsByHotelId(int hotel_id) {
		return roomdetailsrepo.showRoomDetailsByHotelId(hotel_id);
	}

	@Override
	public List<RoomDetails> showRoomTypeByHotelId(int hotel_id) {
		// TODO Auto-generated method stub
		return roomdetailsrepo.showRoomTypeByHotelId(hotel_id);
	}

}
