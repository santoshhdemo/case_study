package com.cg.hbm.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.entites.RoomDetails;
import com.cg.hbm.service.IRoomDetailsService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/RoomDetail")
public class RoomDetailsController {

	@Autowired
	private IRoomDetailsService roomDetailsService;

	@PostMapping(value = "/saveRoomDetails", consumes = "application/json")
	public boolean addRoomDetails(@Valid @RequestBody RoomDetails roomDetails) {
		return roomDetailsService.addRoomDetails(roomDetails);
	}

	@PutMapping("/updateRoomDetails")
	public RoomDetails updateRoomDetails(@Valid @RequestBody RoomDetails roomDetails) {
		return roomDetailsService.updateRoomDetails(roomDetails);
	}

	@DeleteMapping("/removeRoomDetails/{room_id}")
	public boolean removeRoomDetails(@PathVariable int room_id) {
		return roomDetailsService.removeRoomDetails(room_id);
	}

	@GetMapping("/showAllRoomDetails")
	public List<RoomDetails> showAllRoomDetails() {
		return roomDetailsService.showAllRoomDetails();
	}

	@GetMapping("/showRoomDetailsByID/{room_id}")
	public RoomDetails showRoomDetails(@PathVariable int room_id) {
		return roomDetailsService.showRoomDetails(room_id);
	}

	@GetMapping("/showRoomDetailsByIdType/{hotel_id}/{room_type}")
	public List<RoomDetails> showRoomDetailsById(@PathVariable int hotel_id, @PathVariable String room_type) {
		return roomDetailsService.showRoomDetailsByIdType(hotel_id, room_type);
	}
	
	@GetMapping("/showRoomDetailsByHotelId/{hotel_id}")
	public List<RoomDetails> showRoomDetailsByHotelId(@PathVariable int hotel_id) {
		return roomDetailsService.showRoomDetailsByHotelId(hotel_id);
	}
	
	@GetMapping("/showRoomTypeByHotelID/{hotel_id}")
	public List<RoomDetails> showRoomTypeByHotelId(@PathVariable int hotel_id) {
		return roomDetailsService.showRoomTypeByHotelId(hotel_id);
	}

}
