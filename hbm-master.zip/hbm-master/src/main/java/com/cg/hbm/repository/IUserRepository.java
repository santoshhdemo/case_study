package com.cg.hbm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.User;

public interface IUserRepository extends JpaRepository<User, String> {

	@Query(value = "SELECT bk FROM BookingDetails bk WHERE bk.user_email =?1")
	List<BookingDetails> showBookingsByEmail(String user_email);
}
