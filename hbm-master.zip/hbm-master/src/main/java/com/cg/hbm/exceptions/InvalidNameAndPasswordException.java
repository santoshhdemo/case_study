package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class InvalidNameAndPasswordException extends RuntimeException {

	public InvalidNameAndPasswordException() {
	}

	public InvalidNameAndPasswordException(String message) {
		super(message);
	}
}
