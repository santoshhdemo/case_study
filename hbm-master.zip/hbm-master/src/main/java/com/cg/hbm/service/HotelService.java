package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.dto.HotelDTO;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;
import com.cg.hbm.exceptions.HotelNotFoundException;
import com.cg.hbm.repository.IHotelRepository;
import com.cg.hbm.repository.IRoomDetailsRepository;

@Service("hotelService")
@Transactional
public class HotelService implements IHotelService {

	@Autowired
	private IHotelRepository hDao;
	
	@Autowired
	private IRoomDetailsRepository roomdetailsrepo;

	@Override
	public boolean addHotel(HotelDTO hotelDTO) {
		Hotel hotel = new Hotel();
		hotel.setAddress(hotelDTO.getAddress());
		hotel.setCity(hotelDTO.getCity());
		hotel.setDescription(hotelDTO.getDescription());
		hotel.setEmail(hotelDTO.getEmail());
		hotel.setHotel_name(hotelDTO.getHotel_name());
		hotel.setPhone1(hotelDTO.getPhone1());
		hotel.setHeaders(hotelDTO.getHeaders());
		hotel.setImageUrl(hotelDTO.getImageUrl());
		hotel.setAvailable_rooms(hotelDTO.getAvailable_rooms());
		hotel.setWebsite(hotelDTO.getWebsite());
		hDao.save(hotel);
		return true;
	}

	@Override
	public Hotel updateHotel(Hotel hotel) {

		Optional<Hotel> opt = hDao.findById(hotel.getHotel_id());

		if (opt.isPresent())
			hDao.save(hotel);
		else
			throw new HotelNotFoundException("Hotel Does not exist");

		return hotel;
	}

	@Override
	public boolean removeHotel(int hotel_id) {

		Optional<Hotel> opt = hDao.findById(hotel_id);

		if (opt.isPresent()) {
			Hotel hotel = opt.get();
			List<RoomDetails> roomlist = roomdetailsrepo.showRoomDetailsByHotelId(hotel_id);
			
			for(RoomDetails room: roomlist) {
				roomdetailsrepo.delete(room);
			}
			
			hDao.delete(hotel);
		}
		else
			throw new HotelNotFoundException("Hotel Does not exist");

		return true;
	}

	@Override
	public List<Hotel> showAllHotels() {
		return hDao.findAll();
	}

	@Override
	public String showHotelByName(String name) {

		List<Hotel> hotel = hDao.findByName(name);
		String hname;

		if (hotel.isEmpty())
			throw new HotelNotFoundException("Hotel not found");
		else
			hname = hotel.toString();

		return hname;
	}

	@Override
	public String showHotelByCity(String city) {

		List<Hotel> hotel = hDao.findByCity(city);

		if (hotel.isEmpty())
			throw new HotelNotFoundException("No Hotel found in this city");
		else
			return hotel.toString();
	}

	@Override
	public boolean checkAvailability(int hotel_id, int no_of_rooms) {

		Hotel hotel = hDao.findById(hotel_id).orElseThrow(() -> new HotelNotFoundException("Hotel not found"));

		return hotel.getAvailable_rooms() > no_of_rooms;
	}

	@Override
	public List<RoomDetails> showAllRooms(Integer hotel_id) {

		hDao.findById(hotel_id).orElseThrow(() -> new HotelNotFoundException("Hotel not found"));

		return hDao.showAllRooms(hotel_id);
	}

	@Override
	public Hotel showHotelById(int hotel_id) {
		Hotel hotel = hDao.findById(hotel_id).orElseThrow(() -> new HotelNotFoundException("Hotel not found"));
		return hotel;
	}

}
