package com.cg.hbm.service;

import java.util.List;

import com.cg.hbm.dto.PaymentsDTO;
import com.cg.hbm.entites.Payments;

public interface IPaymentService {

	public Payments addPayment(PaymentsDTO paymentDTO);

	public List<Payments> showAllPayments();

}
