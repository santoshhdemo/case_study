package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class TransactionsNotFoundException extends RuntimeException {

	public TransactionsNotFoundException() {
	}

	public TransactionsNotFoundException(String str) {
		super(str);
	}
}
