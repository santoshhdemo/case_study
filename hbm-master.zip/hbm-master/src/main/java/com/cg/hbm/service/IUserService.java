package com.cg.hbm.service;

import java.util.List;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.User;

public interface IUserService {
	public User addUser(User user);

	public User updateUser(User user);

	public User removeUser(String user_email);

	public List<User> showAllUsers();

	public User showUser(String user_email);

	public User userSignIn(String user_email, String password);
	
	public double showUserBalance(String user_email);
	
	public boolean addUserBalance(String user_email, double amount);
	
	public List<BookingDetails> showBookingsByEmail(String user_email);
}
