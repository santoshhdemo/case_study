package com.cg.hbm.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.dto.HotelDTO;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;
import com.cg.hbm.service.IHotelService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/hotel")
public class HotelController {

	@Autowired
	private IHotelService hotelservice;
	
	@PostMapping(value = "/saveHotel", consumes = "application/json")
	public boolean addHotel(@Valid @RequestBody HotelDTO hotelDTO) {
		
		return hotelservice.addHotel(hotelDTO);
	}
	
	@PutMapping("/updateHotelDetails")
	public Hotel updateHotel(@Valid @RequestBody Hotel hotel) {
		
		return hotelservice.updateHotel(hotel);
	}
	
	@DeleteMapping("/deleteHotel/{hotel_id}")
	public boolean removeHotel(@PathVariable int hotel_id) {
		
		return hotelservice.removeHotel(hotel_id);
	}
	
	@GetMapping("/showAllHotels")
	public List<Hotel> showAllHotels(){
		
		return hotelservice.showAllHotels();
	}
	
	@GetMapping("/showHotelByName/{name}")
	public String showHotelByName(@PathVariable String name) {
		
		return hotelservice.showHotelByName(name);
	}
	
	@GetMapping("/showHotelByCity/{city}")
	public String showHotelByCity(@PathVariable String city) {
		
		return hotelservice.showHotelByCity(city);
	}
	
	@GetMapping("/showHotelById/{hotel_id}")
	public Hotel showHotelById(@PathVariable int hotel_id) {
		
		return hotelservice.showHotelById(hotel_id);
	}
	
	
	@GetMapping("/checkAvailability/{hotel_id}/{no_of_rooms}")
	public boolean checkAvailability(@PathVariable int hotel_id, @PathVariable int no_of_rooms){
		
		return hotelservice.checkAvailability(hotel_id, no_of_rooms);
	}
	
	
	@GetMapping("/showAllRooms/{hotel_id}")
	public List<RoomDetails> showAllRooms(@PathVariable Integer hotel_id) {
		
		return hotelservice.showAllRooms(hotel_id);
	}
	
}
