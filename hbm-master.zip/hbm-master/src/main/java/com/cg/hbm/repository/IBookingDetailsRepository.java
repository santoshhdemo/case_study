package com.cg.hbm.repository;

import com.cg.hbm.entites.BookingDetails;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IBookingDetailsRepository extends JpaRepository<BookingDetails, Integer> {

}
