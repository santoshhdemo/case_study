package com.cg.hbm.entites;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
public class BookingDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int booking_id;
	
	@NotNull
	@Email(message = "Invalid email format")
	private String user_email;
	
	@NotNull
	private int hotel_id;
	
	@NotNull
	private int transaction_id;
	
	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate booked_from;
	
	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate booked_to;
	
	@NotNull
	private int no_of_room;
	
	@NotNull
	private String room_type;
	
	private int no_of_adults;
	private int no_of_children;
	private double amount;

	// Extra Properties to maintain ORM relationship
	@ManyToOne()
	private User user;

	@ManyToOne()
	private Hotel hotel;

	@OneToMany()
	private List<RoomDetails> roomDetailsList = new ArrayList<RoomDetails>();

	@OneToOne()
	private Transactions transaction;

	public BookingDetails() {
	}

	public BookingDetails(int booking_id, String user_email, int hotel_id, int transaction_id, LocalDate booked_from,
			LocalDate booked_to, int no_of_room, String room_type, int no_of_adults, int no_of_children, double amount,
			User user, Hotel hotel, List<RoomDetails> roomDetailsList, Transactions transaction) {
		super();
		this.booking_id = booking_id;
		this.user_email = user_email;
		this.hotel_id = hotel_id;
		this.transaction_id = transaction_id;
		this.booked_from = booked_from;
		this.booked_to = booked_to;
		this.no_of_room = no_of_room;
		this.room_type = room_type;
		this.no_of_adults = no_of_adults;
		this.no_of_children = no_of_children;
		this.amount = amount;
		this.user = user;
		this.hotel = hotel;
		this.roomDetailsList = roomDetailsList;
		this.transaction = transaction;
	}

	public int getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public int getHotel_id() {
		return hotel_id;
	}

	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}

	public int getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}

	public LocalDate getBooked_from() {
		return booked_from;
	}

	public void setBooked_from(LocalDate booked_from) {
		this.booked_from = booked_from;
	}

	public LocalDate getBooked_to() {
		return booked_to;
	}

	public void setBooked_to(LocalDate booked_to) {
		this.booked_to = booked_to;
	}

	public int getNo_of_room() {
		return no_of_room;
	}

	public void setNo_of_room(int no_of_room) {
		this.no_of_room = no_of_room;
	}

	public String getRoom_type() {
		return room_type;
	}

	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}

	public int getNo_of_adults() {
		return no_of_adults;
	}

	public void setNo_of_adults(int no_of_adults) {
		this.no_of_adults = no_of_adults;
	}

	public int getNo_of_children() {
		return no_of_children;
	}

	public void setNo_of_children(int no_of_children) {
		this.no_of_children = no_of_children;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public List<RoomDetails> getRoomDetailsList() {
		return roomDetailsList;
	}

	public void setRoomDetailsList(List<RoomDetails> roomDetailsList) {
		this.roomDetailsList = roomDetailsList;
	}

	public Transactions getTransaction() {
		return transaction;
	}

	public void setTransaction(Transactions transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "BookingDetails [booking_id=" + booking_id + ", user_email=" + user_email + ", hotel_id=" + hotel_id
				+ ", transaction_id=" + transaction_id + ", booked_from=" + booked_from + ", booked_to=" + booked_to
				+ ", no_of_room=" + no_of_room + ", room_type=" + room_type + ", no_of_adults=" + no_of_adults
				+ ", no_of_children=" + no_of_children + ", amount=" + amount + ", user=" + user + ", hotel=" + hotel
				+ ", roomDetailsList=" + roomDetailsList + ", transaction=" + transaction + "]";
	}

}
