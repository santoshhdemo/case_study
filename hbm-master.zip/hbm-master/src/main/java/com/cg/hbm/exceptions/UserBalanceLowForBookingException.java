package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class UserBalanceLowForBookingException extends RuntimeException{

	public UserBalanceLowForBookingException() {
	}

	public UserBalanceLowForBookingException(String message) {
		super(message);
	}
}
