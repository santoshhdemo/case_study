package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class RoomDetailsNotFoundException extends RuntimeException {

	public RoomDetailsNotFoundException() {
	}

	public RoomDetailsNotFoundException(String str) {
		super(str);
	}
}
