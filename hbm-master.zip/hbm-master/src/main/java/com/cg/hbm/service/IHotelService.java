package com.cg.hbm.service;

import java.util.List;

import com.cg.hbm.dto.HotelDTO;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;

public interface IHotelService {
	public boolean addHotel(HotelDTO hotelDTO);

	public Hotel updateHotel(Hotel hotel);

	public boolean removeHotel(int hotel_id);

	public List<Hotel> showAllHotels();
	
	public Hotel showHotelById(int hotel_id);

	public String showHotelByName(String name);

	public String showHotelByCity(String city);
	
	public boolean checkAvailability(int hotel_id, int no_of_rooms);
	
	public List<RoomDetails> showAllRooms(Integer hotel_id);
}
