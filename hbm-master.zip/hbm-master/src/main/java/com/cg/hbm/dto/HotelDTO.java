package com.cg.hbm.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class HotelDTO {
	@NotNull(message = "city cannot be null")
	private String city;
	
	@NotNull(message = "hotel_name cannot be null")
	@Size(min=3, max=10, message = "{hotel_name.invalid}")
	private String hotel_name;
	
	private String address;
	private String description;
	private String headers;
	private String imageUrl;
	
	@Email(message = "Invalid email format")
	private String email;
	
	@Pattern(regexp = "^[0-9]{10}", message = "{phone_1.invalid}")
	private String phone1;
	
	@Pattern(regexp = "^(http:\\/\\/www\\.|https:\\/\\/www\\.|http:\\/\\/|https:\\/\\/)?[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,5}(:[0-9]{1,5})?(\\/.*)?$", message = "Website url not valid")
	private String website;
	private int available_rooms;

	public HotelDTO() {
		super();
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHotel_name() {
		return hotel_name;
	}

	public void setHotel_name(String hotel_name) {
		this.hotel_name = hotel_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone1() {
		return phone1;
	}

	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public HotelDTO(String city, String hotel_name, String address, String description,
			String email, String phone1,String website, String imageUrl, String headers) {
		super();
		this.city = city;
		this.hotel_name = hotel_name;
		this.address = address;
		this.description = description;
		this.email = email;
		this.phone1 = phone1;
		this.imageUrl = imageUrl;
		this.headers = headers;
		this.website = website;
	}

	public String getHeaders() {
		return headers;
	}

	public void setHeaders(String headers) {
		this.headers = headers;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public int getAvailable_rooms() {
		return available_rooms;
	}

	public void setAvailable_rooms(int available_rooms) {
		this.available_rooms = available_rooms;
	}
}
