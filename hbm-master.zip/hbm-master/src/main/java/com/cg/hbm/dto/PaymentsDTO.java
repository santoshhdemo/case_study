package com.cg.hbm.dto;

import javax.validation.constraints.NotNull;

public class PaymentsDTO {
	@NotNull(message = "mode cannot be null")
	private String mode;

	public PaymentsDTO() {
		super();
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public PaymentsDTO(String mode) {
		super();
		this.mode = mode;
	}
}
