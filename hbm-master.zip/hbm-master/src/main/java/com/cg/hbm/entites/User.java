package com.cg.hbm.entites;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name = "user_table")
public class User {
	@Id
	@Email(message = "Invalid email format")
	private String user_email;
	
	@NotNull(message = "user_name cannot be null")
	@Pattern(regexp="^[A-Z][a-z]*",message="Name should contain characters")
	private String user_name;
	
	@Size(min=5,max=10,message="It should contain min 5 chars")
	private String password;
	
	private String role;
	
	@Pattern(regexp = "^[0-9]{10}")
	private String mobile;
	private String address;
	
	private double wallet = 100.0;


	public User() {
	}

	public User(String user_email, String user_name, String password, String role, String mobile, String address, double wallet) {
		super();
		this.user_email = user_email;
		this.user_name = user_name;
		this.password = password;
		this.role = role;
		this.mobile = mobile;
		this.address = address;
		this.wallet = wallet;
	}

	public String getEmail() {
		return user_email;
	}

	public void setEmail(String email) {
		this.user_email = email;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getWallet() {
		return wallet;
	}

	public void setWallet(double wallet) {
		this.wallet = wallet;
	}

	@Override
	public String toString() {
		return "User [email=" + user_email + ", user_name=" + user_name + ", password=" + password + ", role=" + role
				+ ", mobile=" + mobile + ", address=" + address + ", wallet=" + wallet + ", bookingDetails="
				+"]";
	}

	
}