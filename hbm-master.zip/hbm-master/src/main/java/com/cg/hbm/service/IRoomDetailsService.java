package com.cg.hbm.service;

import java.util.List;

import com.cg.hbm.entites.RoomDetails;

public interface IRoomDetailsService {
	public boolean addRoomDetails(RoomDetails roomDetails);

	public RoomDetails updateRoomDetails(RoomDetails roomDetails);

	public boolean removeRoomDetails(int room_id);

	public List<RoomDetails> showAllRoomDetails();

	public RoomDetails showRoomDetails(int roomDetails_id);

	public List<RoomDetails> showRoomDetailsByIdType(int hotel_id, String type);
	
	public List<RoomDetails> showRoomDetailsByHotelId(int hotel_id);
	
	public List<RoomDetails> showRoomTypeByHotelId(int hotel_id);
}
