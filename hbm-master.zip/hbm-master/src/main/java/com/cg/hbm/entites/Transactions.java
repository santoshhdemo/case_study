package com.cg.hbm.entites;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
public class Transactions {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int transactions_id;
	
	@NotNull
	private int payment_id;
	
	@NotNull
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate date_of_transaction;   
	private double amount;
	
	@OneToOne()
	@JoinColumn(name = "p_id")
	private Payments payments;

	public Transactions() {
		super();
	}
	
	public int getTransactions_id() {
		return transactions_id;
	}

	public void setTransactions_id(int transactions_id) {
		this.transactions_id = transactions_id;
	}

	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Payments getPayments() {
		return payments;
	}

	public void setPayments(Payments payments) {
		this.payments = payments;
	}

	public int getPayment_id() {
		return payment_id;
	}

	public void setPayment_id(int payment_id) {
		this.payment_id = payment_id;
	}

	public Transactions(int transactions_id, int payment_id, double amount, Payments payments) {
		super();
		this.transactions_id = transactions_id;
		this.payment_id = payment_id;
		this.amount = amount;
		this.payments = payments;
	}

	@Override
	public String toString() {
		return "Transactions [transactions_id=" + transactions_id + ", payment_id=" + payment_id + ", amount=" + amount
				+ ", payments=" + payments + "]";
	}

	public LocalDate getDate_of_transaction() {
		return date_of_transaction;
	}

	public void setDate_of_transaction(LocalDate date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}
}

