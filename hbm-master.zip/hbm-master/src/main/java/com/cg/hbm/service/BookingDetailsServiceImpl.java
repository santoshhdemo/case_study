package com.cg.hbm.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.dto.BookingDTO;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.Payments;
import com.cg.hbm.entites.RoomDetails;
import com.cg.hbm.entites.Transactions;
import com.cg.hbm.entites.User;
import com.cg.hbm.exceptions.BookingDetailsNotFoundException;
import com.cg.hbm.exceptions.BookingFullException;
import com.cg.hbm.exceptions.UserBalanceLowForBookingException;
import com.cg.hbm.repository.IBookingDetailsRepository;
import com.cg.hbm.repository.IHotelRepository;
import com.cg.hbm.repository.IPaymentRepository;
import com.cg.hbm.repository.IRoomDetailsRepository;
import com.cg.hbm.repository.ITransactionsRepository;
import com.cg.hbm.repository.IUserRepository;

@Service("bookingService")
@Transactional
public class BookingDetailsServiceImpl implements IBookingDetailsService {

	@Autowired
	private IBookingDetailsRepository bookingDetailsRepo;

	@Autowired
	private IHotelRepository hotelRepo;

	@Autowired
	private IRoomDetailsRepository roomRepo;

	@Autowired
	private IUserRepository userRepo;

	@Autowired
	private ITransactionsRepository transactionRepo;
	
	@Autowired
	private IPaymentRepository paymentRepo;

	@Override
	public boolean addBookingDetails(BookingDTO bookingDTO) {

		User user = userRepo.getById(bookingDTO.getUser_email());
		Hotel hotel = hotelRepo.getById(bookingDTO.getHotel_id());
		
		Payments payment = new Payments();
		payment.setMode(bookingDTO.getMode());
		Payments resultPayment = paymentRepo.save(payment);
		
		Transactions transaction = new Transactions();
		transaction.setAmount(bookingDTO.getAmount());
		transaction.setPayment_id(resultPayment.getPayment_id());
		transaction.setPayments(resultPayment);
		transaction.setDate_of_transaction(LocalDate.now());
		Transactions resultTransaction = transactionRepo.save(transaction);
		
		List<RoomDetails> roomDetails = roomRepo.showRoomDetailsByIdType(bookingDTO.getHotel_id(),
				bookingDTO.getRoom_type());
		
		List<RoomDetails> availableRooms = new ArrayList<RoomDetails>();
		List<RoomDetails> bookedRooms = new ArrayList<RoomDetails>();
		
		for(RoomDetails room: roomDetails) {
			if(room.isAvailable())
				availableRooms.add(room);
		}
		
		if (availableRooms.size() >= bookingDTO.getNo_of_room()) {
			
			int count = 0;
			Double amount = bookingDTO.getAmount();
//			Double amount = 0.0;
			
			for (RoomDetails room : availableRooms) {
				count++;
//				amount += room.getRate_per_day();
				room.setAvailable(false);
				roomRepo.save(room);
				bookedRooms.add(room);
				if (count >= bookingDTO.getNo_of_room())
					break;
			}
			
			System.out.println(amount);

			if (user.getWallet() > amount) {

				transaction.setAmount(amount);
				transactionRepo.save(transaction);

				user.setWallet(user.getWallet() - amount);
				userRepo.save(user);

				hotel.setAvailable_rooms(hotel.getAvailable_rooms() - bookingDTO.getNo_of_room());
				hotelRepo.save(hotel);

				BookingDetails bookingDetails = new BookingDetails();
				bookingDetails.setBooked_from(bookingDTO.getBooked_from());
				bookingDetails.setBooked_to(bookingDTO.getBooked_to());
				bookingDetails.setNo_of_adults(bookingDTO.getNo_of_adults());
				bookingDetails.setNo_of_children(bookingDTO.getNo_of_children());
				bookingDetails.setNo_of_room(bookingDTO.getNo_of_room());
				bookingDetails.setRoom_type(bookingDTO.getRoom_type());
				bookingDetails.setAmount(amount);
				bookingDetails.setTransaction(resultTransaction);
				bookingDetails.setTransaction_id(resultTransaction.getTransactions_id());
				bookingDetails.setHotel_id(bookingDTO.getHotel_id());
				bookingDetails.setUser_email(bookingDTO.getUser_email());
				bookingDetails.setUser(user);
				bookingDetails.setHotel(hotel);
				bookingDetails.setRoomDetailsList(bookedRooms);
				
				bookingDetailsRepo.save(bookingDetails);
				
				return true;
			} else
				throw new UserBalanceLowForBookingException("User Balance is less than booking amount");

		} else
			throw new BookingFullException("No booking is available");
	}

	@Override
	public boolean updateBookingDetails(BookingDetails bookingDetails) {

		Optional<BookingDetails> result = bookingDetailsRepo.findById(bookingDetails.getBooking_id());

		if (result.isPresent()) {
			BookingDetails prevBooking = result.get();

			User prevUser = userRepo.getById(prevBooking.getUser_email());

			Hotel prevHotel = hotelRepo.getById(prevBooking.getHotel_id());

			Transactions prevTransaction = transactionRepo.getById(prevBooking.getTransaction_id());

			List<RoomDetails> oldRooms = prevBooking.getRoomDetailsList();

			int count = 0;
			Double amount = 0.0;
			for (RoomDetails room : oldRooms) {
				count++;
				amount += room.getRate_per_day();
				room.setAvailable(true);
				roomRepo.save(room);

				if (count >= prevBooking.getNo_of_room())
					break;
			}

			prevTransaction.setAmount(0.0);
			transactionRepo.save(prevTransaction);

			prevUser.setWallet(prevUser.getWallet() + amount);
			userRepo.save(prevUser);

			prevHotel.setAvailable_rooms(prevHotel.getAvailable_rooms() + prevBooking.getNo_of_room());
			hotelRepo.save(prevHotel);
			
			User user = userRepo.getById(bookingDetails.getUser_email());

			Hotel hotel = hotelRepo.getById(bookingDetails.getHotel_id());

			Transactions transaction = transactionRepo.getById(bookingDetails.getTransaction_id());

			List<RoomDetails> roomDetails = roomRepo.showRoomDetailsByIdType(bookingDetails.getHotel_id(),
					bookingDetails.getRoom_type());
			
			List<RoomDetails> availableRooms = new ArrayList<RoomDetails>();
			List<RoomDetails> bookedRooms = new ArrayList<RoomDetails>();
			
			for(RoomDetails room: roomDetails) {
				if(room.isAvailable())
					availableRooms.add(room);
			}

			if (availableRooms.size() >= bookingDetails.getNo_of_room()) {

				int count1 = 0;
//				Double amount1 = 0.0;
				Double amount1 = bookingDetails.getAmount();
				
				for (RoomDetails room1 : availableRooms) {
					count1++;
//					amount1 += room1.getRate_per_day();
					room1.setAvailable(false);
					roomRepo.save(room1);
					bookedRooms.add(room1);
					if (count1 >= bookingDetails.getNo_of_room())
						break;
				}

				if (user.getWallet() > amount1) {

					transaction.setAmount(amount1);
					transactionRepo.save(transaction);

					user.setWallet(user.getWallet() - amount1);
					userRepo.save(user);

					hotel.setAvailable_rooms(hotel.getAvailable_rooms() - bookingDetails.getNo_of_room());
					hotelRepo.save(hotel);

					bookingDetails.setAmount(amount1);
					bookingDetails.setTransaction(transaction);
					bookingDetails.setUser(user);
					bookingDetails.setHotel(hotel);
					bookingDetails.setRoomDetailsList(bookedRooms);
					bookingDetailsRepo.save(bookingDetails);
					
					return true;
				} else
					throw new UserBalanceLowForBookingException("User Balance is less than booking amount");

			} else
				throw new BookingFullException("No booking is available");

		} else
			throw new BookingDetailsNotFoundException("No such booking available to update");
	}

	@Override
	public String removeBookingDetails(int bookingId) {
		BookingDetails result = bookingDetailsRepo.findById(bookingId)
				.orElseThrow(() -> new BookingDetailsNotFoundException("No such booking available to delete"));
		bookingDetailsRepo.delete(result);
		return "Record Deleted successfully";
	}

	@Override
	public List<BookingDetails> showAllBookingDetails() {
		return bookingDetailsRepo.findAll();
	}

	@Override
	public BookingDetails showBookingDetails(int bookingId) {
		BookingDetails result = bookingDetailsRepo.findById(bookingId)
				.orElseThrow(() -> new BookingDetailsNotFoundException("No such booking available to delete"));
		return result;
	}
}
