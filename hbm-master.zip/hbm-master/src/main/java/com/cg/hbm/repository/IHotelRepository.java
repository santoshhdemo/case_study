package com.cg.hbm.repository;

import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface IHotelRepository extends JpaRepository<Hotel, Integer>{
	
	@Query("select h from Hotel h where h.hotel_name=?1")
	public List<Hotel> findByName(String hotel_name);
	
	public List<Hotel> findByCity(String city);
	 
	@Query("select r from RoomDetails r where r.hotel_id=?1")
	public List<RoomDetails> showAllRooms(Integer hotel_id);
}
