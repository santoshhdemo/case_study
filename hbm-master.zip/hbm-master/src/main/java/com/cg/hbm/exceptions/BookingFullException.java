package com.cg.hbm.exceptions;

@SuppressWarnings("serial")
public class BookingFullException extends RuntimeException {

	public BookingFullException() {
	}

	public BookingFullException(String message) {
		super(message);
	}
}
