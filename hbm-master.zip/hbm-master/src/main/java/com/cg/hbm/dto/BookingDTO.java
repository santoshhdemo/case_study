package com.cg.hbm.dto;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class BookingDTO {

	@NotNull(message = "user_email cannot be null")
	@Email(message = "Invalid email format")
	private String user_email;
	
	@NotNull(message = "hotel_id cannot be null")
	private int hotel_id;
	
	@NotNull(message = "mode cannot be null")
	private String mode;
	
	@NotNull(message = "booked_from cannot be null")
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate booked_from;
	
	@NotNull(message = "booked_to cannot be null")
	@DateTimeFormat(iso = ISO.DATE)
	private LocalDate booked_to;
	
	@NotNull(message = "no_of_room cannot be null")
	private int no_of_room;
	
	@NotNull(message = "room_type cannot be null")
	private String room_type;
	
	private int no_of_adults;
	private int no_of_children;
	private double amount;
	
	public BookingDTO() {
		super();
	}
	
	public BookingDTO(String user_email, int hotel_id, String mode, LocalDate booked_from, LocalDate booked_to,
			int no_of_room, String room_type, int no_of_adults, int no_of_children, double amount) {
		super();
		this.user_email = user_email;
		this.hotel_id = hotel_id;
		this.mode = mode;
		this.booked_from = booked_from;
		this.booked_to = booked_to;
		this.no_of_room = no_of_room;
		this.room_type = room_type;
		this.no_of_adults = no_of_adults;
		this.no_of_children = no_of_children;
		this.amount = amount;
	}

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public int getHotel_id() {
		return hotel_id;
	}

	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}


	public LocalDate getBooked_from() {
		return booked_from;
	}

	public void setBooked_from(LocalDate booked_from) {
		this.booked_from = booked_from;
	}

	public LocalDate getBooked_to() {
		return booked_to;
	}

	public void setBooked_to(LocalDate booked_to) {
		this.booked_to = booked_to;
	}

	public int getNo_of_room() {
		return no_of_room;
	}

	public void setNo_of_room(int no_of_room) {
		this.no_of_room = no_of_room;
	}

	public String getRoom_type() {
		return room_type;
	}

	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}

	public int getNo_of_adults() {
		return no_of_adults;
	}

	public void setNo_of_adults(int no_of_adults) {
		this.no_of_adults = no_of_adults;
	}

	public int getNo_of_children() {
		return no_of_children;
	}

	public void setNo_of_children(int no_of_children) {
		this.no_of_children = no_of_children;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
}
