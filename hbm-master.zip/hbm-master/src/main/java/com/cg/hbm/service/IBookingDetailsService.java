package com.cg.hbm.service;

import java.util.List;

import com.cg.hbm.dto.BookingDTO;
import com.cg.hbm.entites.BookingDetails;

public interface IBookingDetailsService {

	public boolean addBookingDetails(BookingDTO bookingDTO);

	public boolean updateBookingDetails(BookingDetails bookingDetails);

	public String removeBookingDetails(int bookingId);

	public List<BookingDetails> showAllBookingDetails();

	public BookingDetails showBookingDetails(int bookingId);
}
