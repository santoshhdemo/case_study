package com.cg.hbm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hbm.entites.Transactions;

public interface ITransactionsRepository extends JpaRepository<Transactions, Integer> {

}