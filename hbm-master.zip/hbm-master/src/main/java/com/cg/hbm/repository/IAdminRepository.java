package com.cg.hbm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hbm.entites.Admin;

public interface IAdminRepository extends JpaRepository<Admin, String> {

}
