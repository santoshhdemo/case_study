package com.cg.hbm;

import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.cg.hbm.service.HotelService;

@Profile("test")
@Configuration
public class TestConfiguration {

	@Bean
	public HotelService hotelService() {
		return Mockito.mock(HotelService.class);
	}
}
