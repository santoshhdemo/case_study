package com.cg.hbm;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import com.cg.hbm.dto.BookingDTO;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entites.RoomDetails;
import com.cg.hbm.entites.Transactions;
import com.cg.hbm.entites.User;
import com.cg.hbm.repository.IBookingDetailsRepository;
import com.cg.hbm.repository.IHotelRepository;
import com.cg.hbm.repository.IRoomDetailsRepository;
import com.cg.hbm.repository.ITransactionsRepository;
import com.cg.hbm.repository.IUserRepository;
import com.cg.hbm.service.BookingDetailsServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class TestBookingService {

	@InjectMocks
	private BookingDetailsServiceImpl bookingDetailsService;

	@Mock
	private IBookingDetailsRepository bookingDetailsDao;

	@Mock
	private IUserRepository userRepo;

	@Mock
	private IHotelRepository hotelRepo;

	@Mock
	private IRoomDetailsRepository roomDetailsRepo;

	@Mock
	private ITransactionsRepository transactionRepo;

	@BeforeEach
	void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testAddBookingDetails() {

		BookingDetails bookingDetails = new BookingDetails();
		BookingDetails bookingDetailsUpdate = new BookingDetails();
		BookingDTO bookingDTO = new BookingDTO();

		Transactions transaction = mock(Transactions.class);
		bookingDetails.setTransaction(transaction);

		User user = new User();
		Hotel hotel = new Hotel();
		Transactions trans = new Transactions();
		List<RoomDetails> roomList = new ArrayList<RoomDetails>();

		bookingDetailsUpdate.setUser(user);

		when(userRepo.getById("abd@xyz.com")).thenReturn(user);
		when(hotelRepo.getById(1)).thenReturn(hotel);
		when(transactionRepo.getById(1)).thenReturn(trans);
		when(roomDetailsRepo.showRoomDetailsByIdType(1, "AC")).thenReturn(roomList);
		when(bookingDetailsService.addBookingDetails(bookingDTO)).thenReturn(true);

		boolean result = bookingDetailsService.addBookingDetails(bookingDTO);

		assertEquals(true, result, "Correct object received");
	}

	@Test
	public void testUpdateBookingDetails() {

		BookingDetails bookingDetails = mock(BookingDetails.class);
		BookingDetails updatedBookingDetails = mock(BookingDetails.class);

		when(bookingDetailsService.updateBookingDetails(bookingDetails)).thenReturn(true);

		boolean result = bookingDetailsService.updateBookingDetails(bookingDetails);

		assertEquals(result, updatedBookingDetails, "Correct object received");
	}

	@Test
	public void testRemoveBookingDetails() {
		BookingDetails bookingDetails = mock(BookingDetails.class);

		when(bookingDetailsService.removeBookingDetails(bookingDetails.getBooking_id()))
				.thenReturn("Record Deleted successfully");

		String result = bookingDetailsService.removeBookingDetails(bookingDetails.getBooking_id());

		assertEquals(result, "Record Deleted successfully", "Correct object received");
	}

	@Test
	public void testShowAllBookingDetails() {
		BookingDetails bookingDetails = mock(BookingDetails.class);
		List<BookingDetails> bookingList = new ArrayList<BookingDetails>();
		bookingList.add(bookingDetails);

		when(bookingDetailsService.showAllBookingDetails()).thenReturn(bookingList);

		List<BookingDetails> result = bookingDetailsService.showAllBookingDetails();

		assertEquals(result, bookingList, "Correct object received");
	}

	@Test
	public void testShowBookingDetails() {
		BookingDetails bookingDetails = mock(BookingDetails.class);

		when(bookingDetailsService.showBookingDetails(bookingDetails.getBooking_id())).thenReturn(bookingDetails);

		BookingDetails result = bookingDetailsService.showBookingDetails(bookingDetails.getBooking_id());

		assertEquals(result, bookingDetails, "Correct object received");
	}
}
