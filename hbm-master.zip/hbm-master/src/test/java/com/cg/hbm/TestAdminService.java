package com.cg.hbm;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cg.hbm.entites.Admin;
import com.cg.hbm.repository.IAdminRepository;
import com.cg.hbm.service.AdminServicesImpl;

@ExtendWith(SpringExtension.class)
public class TestAdminService {

	
	@InjectMocks
	private AdminServicesImpl adminService;
	
	
	@Mock
	private IAdminRepository adminDao;

	
	@BeforeEach
	void init() {
		
		MockitoAnnotations.openMocks(this);
		
	}

	@Test
	public void testsignIn() {

    	Admin admin = mock(Admin.class);
    	String admin_email = "abc@xyz.com";
    	String password = "ram";

    	when(adminService.signIn(admin_email, password)).thenReturn(admin);

		Admin result = adminService.signIn(admin_email, password);
		assertEquals(result, admin, "Successfull SignIn");
	}
	
	@Test
	public void testsaveAdmin() {

    	Admin admin = mock(Admin.class);
    	Admin newAdmin = mock(Admin.class);

    	when(adminService.saveAdmin(admin)).thenReturn(newAdmin);
    	Admin result = adminService.saveAdmin(admin);
    	assertEquals(result, newAdmin, "Save Admin Successfull");
	}
	
	@Test
	public void testupdateAdmin() {

	    	Admin adminDetails = mock(Admin.class);
	    	Admin updatedAdminDetails = mock(Admin.class);
	    	
	    	when(adminService.updateAdmin(adminDetails)).thenReturn(updatedAdminDetails);
	    	
	    	Admin result = adminService.updateAdmin(adminDetails);
	    	
	    	assertEquals(result, updatedAdminDetails, "Updation Successfull");
	}
	
	@Test
	public void testdeleteAdmin() {
		Admin adminDetails = mock(Admin.class);
    	
		when(adminService.deleteAdmin("abc@xyz.com")).thenReturn(adminDetails);
    	
    	Admin result = adminService.deleteAdmin("abc@xyz.com");
    	
    	assertEquals(result, adminDetails, "Correct object received");
	}
	
	 @Test
	    public void testShowAllAdminDetails() {
	    	Admin adminDetails = mock(Admin.class);
	    	List<Admin> adminList = new ArrayList<Admin>();
	    	adminList.add(adminDetails);
	    	
	    	when(adminService.showAllAdmin()).thenReturn(adminList);
	    	
	    	List<Admin> result = adminService.showAllAdmin();
	    	
	    	assertEquals(result, adminList, "Correct object received");
	    }
	

}
