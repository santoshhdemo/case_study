package com.cg.hbm;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cg.hbm.dto.HotelDTO;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.repository.IHotelRepository;
import com.cg.hbm.service.HotelService;

@ExtendWith(SpringExtension.class)
public class TestHotelService {

	@InjectMocks
	private HotelService hotelsevice;

	@Mock
	private IHotelRepository hoteldao;

	@BeforeEach
	void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testAddHotelDetails() {

		HotelDTO hotel = mock(HotelDTO.class);

		when(hotelsevice.addHotel(hotel)).thenReturn(true);

		Boolean result = hotelsevice.addHotel(hotel);

		assertEquals(result, true, "Wrong object Recieved");
	}

	@Test
	public void testUpdateHotelDetails() {

		Hotel hotel = mock(Hotel.class);

		when(hotelsevice.updateHotel(hotel)).thenReturn(hotel);

		Hotel result = hotelsevice.updateHotel(hotel);

		assertEquals(result, hotel, "Hotel is not updated");
	}

	@Test
	public void testRemoveHotelDetails() {

		Hotel hotel = mock(Hotel.class);

		when(hotelsevice.removeHotel(hotel.getHotel_id())).thenReturn(true);

		Boolean result = hotelsevice.removeHotel(hotel.getHotel_id());

		assertEquals(result, true, "Wrong object Recieved");
	}

	@Test
	public void testShowAllHotels() {

		List<Hotel> hotel = Arrays.asList(mock(Hotel.class), mock(Hotel.class), mock(Hotel.class));

		when(hotelsevice.showAllHotels()).thenReturn(hotel);

		List<Hotel> result = hotelsevice.showAllHotels();

		assertEquals(result, hotel, "Wrong object Recieved");
	}

	@Test
	public void testshowHotelByName() {

		String name = "Ishan";

		String hotel = mock(Hotel.class).toString();

		when(hotelsevice.showHotelByName(name)).thenReturn(hotel);

		String result = hotelsevice.showHotelByName(name);

		assertEquals(result, hotel, "Wrong object Recieved");
	}

	/*
	 * @Test public void testshowHotelByPriceBetween() {
	 * 
	 * Double d1 = 10.0; Double d2 = 150.0;
	 * 
	 * String hotel = Arrays.asList(mock(Hotel.class), mock(Hotel.class),
	 * mock(Hotel.class)).toString();
	 * 
	 * when(hotelsevice.showHotelByPriceBetween(d1, d2)).thenReturn(hotel);
	 * 
	 * String result = hotelsevice.showHotelByPriceBetween(d1, d2);
	 * 
	 * assertEquals(result, hotel, "Wrong object Recieved"); }
	 */

	@Test
	public void testshowHotelByCity() {

		String city = "Chennai";

		String hotel = Arrays.asList(mock(Hotel.class), mock(Hotel.class), mock(Hotel.class)).toString();

		when(hotelsevice.showHotelByCity(city)).thenReturn(hotel);

		String result = hotelsevice.showHotelByCity(city);

		assertEquals(result, hotel, "Wrong object Recieved");
	}

	@Test
	public void testcheckAvailability() {

		Hotel hotel = mock(Hotel.class);

		int no_of_room = 10;

		when(hotelsevice.checkAvailability(hotel.getHotel_id(), no_of_room)).thenReturn(true);

		Boolean result = hotelsevice.checkAvailability(hotel.getHotel_id(), no_of_room);

		assertEquals(result, true, "Wrong object Recieved");
	}

}
