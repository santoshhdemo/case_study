package com.bookingMicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingMiceoserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
